#install.packages("caTools")
library(caTools)
#install.packages('dplyr')    #for Data Manipulation
library(dplyr)
#install.packages('ggplot2')  #for Data Visualization
library(ggplot2)
#install.packages('class')    #KNN 
library(class)
#install.packages('caret')    #Confusion Matrix
library(caret)
#install.packages('corrplot') #Correlation Plot
library(corrplot)
set.seed(1)
library(class)
d = read.csv(file.choose())
d = data.frame(d)



types <- table(d$type)
d_target <- d[, 18]
d_key <- d[, 1]
d$animal <- NULL

names(types) <- c("mammal", "bird", "reptile", "fish", "amphibian", "insect", "crustacean")
types

summary(d)
str(d)
# convert the type output variable to factors
d$type <- as.factor(d$type)
# remove the first column as we donot use it for analysis
d <- d[,-1]
attach(d)


# you have to train and test your data first and
# then apply KNN on it 










k = sqrt(17) + 1
m1 <- knn.cv(d, d_target, k, prob = TRUE)
prediction <- m1

cmat <- table(d_target,prediction)
acc <- (sum(diag(cmat)) / length(d_target)) * 100
print(acc)
